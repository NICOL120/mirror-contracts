use cw_multi_test::App;

pub fn mock_app() -> App {
    App::default()
}
