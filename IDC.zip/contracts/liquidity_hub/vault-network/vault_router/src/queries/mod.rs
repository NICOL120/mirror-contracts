mod config;

pub use config::get_config;
