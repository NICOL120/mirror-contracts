# TerraSwap Pair

The pair contract is the pool itself. Creating a new pool should be done via the pool factory, so that the pool is indexed
in the pool registry stored by the factory. A pool can be created with native, ibc or cw20 tokens.

To find out more about the pair contract, refer to the [Migaloo docs](https://ww0-1.gitbook.io/migaloo-docs/liquidity-hub/overview-1/terraswap-pair).
