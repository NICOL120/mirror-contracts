# White Whale Package

This is a collection of types and helpers commonly used across White Whale contracts.