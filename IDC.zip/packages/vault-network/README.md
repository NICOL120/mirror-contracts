# Vault Network Package

This is a collection of types used by the Vault Network contracts.